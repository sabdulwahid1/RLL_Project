package com.example.project.Services;

import com.example.project.Models.Place;
import com.example.project.Repositories.PlaceDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PlaceService {

    @Autowired
    PlaceDAO placeDAO;

    public String createPlaceSuggestion(Place request) {

        try {
            placeDAO.save(request);
            return "Added Place!";

        }catch (Exception ex)
        {
            return ex.getMessage();
        }

    }

    public String updatePlaceSuggestion(Place request){

        try{

            Optional<Place> response = placeDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getId()==request.getId())
                    .findFirst();

            if(!response.isPresent())
            {
                return "Invalid Tour Id";
            }

            response.get().setUserID(request.getUserID());
            response.get().setPlaceName(request.getPlaceName());
            response.get().setPlaceCategory(request.getPlaceCategory());
            response.get().setPlaceDescription(request.getPlaceDescription());
            placeDAO.save(response.get());

            return "Update Place successfully";

        }catch (Exception ex){
            return ex.getMessage();
        }

    }

    public List<Place> getAllPlaceSuggestions(){

        try{
            return placeDAO
                    .findAll()
                    .stream()
                    .toList();

        }catch (Exception ex){
            return null;
        }
    }

    public String deletePlaceSuggestion(Long Id){

        try{

            Optional<Place> response = placeDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getId()==Id)
                    .findFirst();

            if(!response.isPresent())
            {
                return "Invalid Tour Id";
            }

            placeDAO.delete(response.get());

            return "Delete Place Successfully";

        }catch (Exception ex){
            return null;
        }
    }
}
