package com.example.project.Models;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Table(name = "travel_experience")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class TravelExperience {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    
    private Long userID;

    private String location;
    private String images;
    private double costOfTravel;
    private String heritages;
    private String placesToVisit;
    private String accessibility;
    private String transportation;
    private String climate;
    private String safety;

    // Constructors, getters, and setters
}
