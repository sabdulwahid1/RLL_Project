package com.example.project.Controllers;

import com.example.project.DTO.*;
import com.example.project.Models.Comment;
import com.example.project.Models.TravelExperience;
import com.example.project.Services.UserService;
import com.example.project.Utils.JWTUtil;
import com.example.project.Utils.RoleConfig;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("api/user")
public class UserController {

    @Autowired
    UserService userService;

    @Autowired
    private JWTUtil jwtUtility;

    @Autowired
    private RoleConfig roleConfig;

    Date currentDate = new Date();

    @PostMapping("/addComment")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity addComment(@RequestBody Comment request) {
        try {


            String response = userService.addComment(request);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity<>(_response, HttpStatus.OK);
        }
        catch (Exception ex) {
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/user/addUserTour");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/updateComment")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity updateComment(@RequestBody Comment request) {


        try {
            String response = userService.updateComment(request);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity<>(null, HttpStatus.OK);
        }
        catch (Exception ex) {
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/user/updateUserTour");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/getAllComments")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity getAllComments(@RequestParam Long id) {

        try {
            List<CommentResponseDTO> response = userService.getAllComments(id);
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        catch (Exception ex) {
            Date currentDate = new Date();
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/api/admin/user");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    @DeleteMapping("/deleteComment")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity deleteComment(@RequestParam Long id) {

        try {
            String response = userService.deleteComment(id);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity<>(null, HttpStatus.OK);
        }
        catch (Exception ex) {
            Date currentDate = new Date();
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/api/user/deleteUserTour");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    @PostMapping("/createTravelExperience")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity createTravelExperience(@RequestBody TravelExperience request) {

        try {

            String response = userService.createTravelExperience(request);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity<>(_response, HttpStatus.OK);
        }
        catch (Exception ex) {
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/user/addProfileDetail");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/updateTravelExperience")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity updateTravelExperience(@RequestBody TravelExperience request) {


        try {
            String response = userService.updateTravelExperience(request);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity<>(_response, HttpStatus.OK);
        }
        catch (Exception ex) {
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/user/updateProfileDetail");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }


    @GetMapping("/getAllTravelExperiences")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity getAllTravelExperiences(@RequestParam String locationName) {

        try {
            List<TravelExperience> response = userService.getAllTravelExperiences(locationName);
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        catch (Exception ex) {
            Date currentDate = new Date();
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/api/admin/user");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    //

    @GetMapping("/getTravelExperiencesList")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity getTravelExperiencesList() {

        try {
            List<TravelExperience> response = userService.getAllTravelExperiencesList();
            return new ResponseEntity<>(response, HttpStatus.OK);
        }
        catch (Exception ex) {
            Date currentDate = new Date();
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/api/admin/user");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }


    @DeleteMapping("/deleteTravelExperience")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity deleteTravelExperience(@RequestParam Long Id) {

        try {
            String response = userService.deleteTravelExperience(Id);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity<>(_response, HttpStatus.OK);
        }
        catch (Exception ex) {
            Date currentDate = new Date();
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/api/admin/user");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

}
