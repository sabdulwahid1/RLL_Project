package com.example.project.Services;

import com.example.project.DTO.*;
import com.example.project.Models.Comment;
import com.example.project.Models.TravelExperience;
import com.example.project.Repositories.CommentDAO;
import com.example.project.Repositories.TravelExperienceDAO;
import com.example.project.Repositories.UserDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    UserDAO userDAO;

    @Autowired
    CommentDAO commentDAO;

    @Autowired
    TravelExperienceDAO travelExperienceDAO;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private AuthenticationManager authenticationManager;

    public String addComment(Comment request){
        try{
            commentDAO.save(request);
            return "Add User Comment Successfully";

        }catch (Exception ex){
            return null;
        }
    }

    public String updateComment(Comment request){
        try{

            Optional<Comment> response = commentDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getId()== request.getId())
                    .findFirst();

            if(!response.isPresent()){
                return "Comment Not Found";
            }

            response.get().setText(request.getText());
            commentDAO.save(response.get());
            return "Update Comment Successfully";

        }catch (Exception ex){
            return null;
        }
    }

    public List<CommentResponseDTO> getAllComments(Long Id){
        try{
            List<CommentResponseDTO> responseDTO = new ArrayList<>();
            List<Comment> data = commentDAO.findAll().stream().filter(x->x.getExperienceID()==Id).toList();
            data.forEach(x->{
                CommentResponseDTO getData = new CommentResponseDTO();
                getData.setId(x.getId());
                getData.setUserID(x.getUserID());
                String email = x.getUserID()==0?"ADMIN": userDAO.findAll().stream().filter(x1->x1.getUserId()==x.getUserID()).findFirst().get().getEmail();
                getData.setUserName(email);
                getData.setDate(x.getDate());
                getData.setExperienceID(x.getExperienceID());
                String location = travelExperienceDAO.findAll().stream().filter(x1->x1.getId()==x.getExperienceID()).findFirst().get().getLocation();
                getData.setLocation(location);
                getData.setText(x.getText());
                responseDTO.add(getData);
            });

            return responseDTO;
        }catch (Exception ex){
            return null;
        }
    }

    public String deleteComment(Long Id){
        try{

            Optional<Comment> response = commentDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getId()==Id)
                    .findFirst();

            if(!response.isPresent()){
                return "Comment Not Present";
            }

            commentDAO.delete(response.get());
            return "Delete Comment Successfully";

        }
        catch (Exception ex){
            return null;
        }

    }

    public String createTravelExperience(TravelExperience request){
        try{

            travelExperienceDAO.save(request);
            return "Add User Booking Successfully";

        }catch (Exception ex){
            return null;
        }
    }

    public String updateTravelExperience(TravelExperience request){
        try{

            Optional<TravelExperience> response = travelExperienceDAO
                    .findAll()
                    .stream()
                    .filter(x->x.getId()== request.getId())
                    .findFirst();

            if(!response.isPresent()){
                return "Travel Experience Detail Not Present";
            }

//            private String location;
//            private String images;
//            private double costOfTravel;
//            private String heritages;
//            private String placesToVisit;
//            private String accessibility;
//            private String transportation;
//            private String climate;
//            private String safety;

            TravelExperience travelExperience = response.get();
            travelExperience.setLocation(request.getLocation());
            travelExperience.setImages(request.getImages());
            travelExperience.setCostOfTravel(request.getCostOfTravel());
            travelExperience.setHeritages(request.getHeritages());

            travelExperience.setPlacesToVisit(request.getPlacesToVisit());
            travelExperience.setAccessibility(request.getAccessibility());
            travelExperience.setTransportation(request.getTransportation());
            travelExperience.setClimate(request.getClimate());
            travelExperience.setSafety(request.getSafety());
            travelExperienceDAO.save(request);
            return "Update Travel Experience Successfully";

        }catch (Exception ex){
            return null;
        }
    }
    public List<TravelExperience>  getAllTravelExperiences(String locationName){

        try{
            return travelExperienceDAO.findAll().stream().filter(x->x.getLocation().equalsIgnoreCase(locationName)).toList();
        }catch (Exception ex){
            return null;
        }
    }

    //
    public List<TravelExperience>  getAllTravelExperiencesList(){

        try{
            return travelExperienceDAO.findAll().stream().toList();
        }catch (Exception ex){
            return null;
        }
    }
    public String deleteTravelExperience(Long Id)
    {
        try{

            Optional<TravelExperience> response = travelExperienceDAO.findAll().stream().filter(x->x.getId()==Id).findFirst();

            if(!response.isPresent()){
                return "Travel Experience Not Present";
            }

            travelExperienceDAO.delete(response.get());
            return "Delete Travel Experience Successfully";

        }catch (Exception ex){
            return null;
        }
    }
}
