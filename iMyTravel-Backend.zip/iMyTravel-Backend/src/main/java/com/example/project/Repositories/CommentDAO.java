package com.example.project.Repositories;

import com.example.project.Models.Comment;
import com.example.project.Models.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CommentDAO extends JpaRepository<Comment, Long> {
}
