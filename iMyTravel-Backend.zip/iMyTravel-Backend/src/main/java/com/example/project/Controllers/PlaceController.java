package com.example.project.Controllers;

import com.example.project.DTO.*;
import com.example.project.Models.Place;
import com.example.project.Services.PlaceService;
import com.example.project.Utils.RoleConfig;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("api/admin")
public class PlaceController {

    @Autowired
    PlaceService placeService;

    @Autowired
    private RoleConfig roleConfig;

    Date currentDate = new Date();

    @PostMapping("/createPlaceSuggestion")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity createPlaceSuggestion(@RequestBody Place request) {
        try{

            String response = placeService.createPlaceSuggestion(request);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity<>(_response, HttpStatus.OK);

        }catch (Exception ex){
            Date currentDate = new Date();
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/api/acct/payments");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    @PutMapping("/updatePlaceSuggestion")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity updatePlaceSuggestion(@RequestBody Place request){
        try{
            String response = placeService.updatePlaceSuggestion(request);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity(_response, HttpStatus.OK);

        }catch (Exception ex){
            BasicResponseErrorDTO data =  new BasicResponseErrorDTO<>(currentDate.toString(),"400","Bad Request",ex.getMessage(), "/api/admin/updatetourlocation");
            return new ResponseEntity<>(data, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/getAllPlaceSuggestions")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity getAllPlaceSuggestions(){
        try{
            List<Place> response = placeService.getAllPlaceSuggestions();
            return new ResponseEntity(response, HttpStatus.OK);

        }catch (Exception ex){

            return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);

        }
    }


    @DeleteMapping("/deletePlaceSuggestion")
    @Operation( security = @SecurityRequirement(name = "bearerAuth"))
    public ResponseEntity deletePlaceSuggestion(@RequestParam Long Id){

        try{
            String response = placeService.deletePlaceSuggestion(Id);
            BasicResponseDTO _response = new BasicResponseDTO();
            _response.setMessage(response);
            return new ResponseEntity(_response, HttpStatus.OK);

        }catch (Exception ex){

            return new ResponseEntity<>(ex.getMessage(), HttpStatus.BAD_REQUEST);

        }
    }

}
