package com.example.project.Repositories;

import com.example.project.Models.TravelExperience;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TravelExperienceDAO extends JpaRepository<TravelExperience, Long> {
}
