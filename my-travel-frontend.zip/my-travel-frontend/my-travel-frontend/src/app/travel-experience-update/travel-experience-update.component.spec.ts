import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TravelExperienceUpdateComponent } from './travel-experience-update.component';

describe('TravelExperienceUpdateComponent', () => {
  let component: TravelExperienceUpdateComponent;
  let fixture: ComponentFixture<TravelExperienceUpdateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TravelExperienceUpdateComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(TravelExperienceUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
