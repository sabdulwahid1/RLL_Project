import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TravelExperience } from '../travel-experience';
import { TravelExperienceService } from '../travel-experience.service';

@Component({
  selector: 'app-travel-experience-update',
  templateUrl: './travel-experience-update.component.html',
  styleUrl: './travel-experience-update.component.css'
})
export class TravelExperienceUpdateComponent implements OnInit {
  experienceId: number;
  travelExperience: TravelExperience;

  constructor(private route: ActivatedRoute, private router: Router, private travelExperienceService: TravelExperienceService) { }

  ngOnInit(): void {
    // Extract experienceId from route params
    this.experienceId = +this.route.snapshot.paramMap.get('id');
    // Fetch travel experience details based on experienceId
    this.travelExperienceService.getTravelExperienceById(this.experienceId).subscribe(experience => {
      this.travelExperience = experience;
    });
  }

  updateTravelExperience(): void {
    this.travelExperienceService.updateTravelExperience(this.experienceId, this.travelExperience).subscribe(() => {
      this.router.navigate(['/travel-experiences']); // Redirect to travel experience list after update
    });
  }
}