export class Comment {
    id: number;
    experienceId: number;
    userId: number;
    commentText: string;
    commentDate: Date;
  }
  