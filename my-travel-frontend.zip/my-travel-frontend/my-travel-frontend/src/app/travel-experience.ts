export class TravelExperience {
    id: number;
    userId: number;
    location: string;
    images: string;
    costOfTravel: number;
    heritages: string;
    placesToVisit: string;
    accessibility: string;
    transportation: string;
    climate: string;
    safety: string;
  }
  