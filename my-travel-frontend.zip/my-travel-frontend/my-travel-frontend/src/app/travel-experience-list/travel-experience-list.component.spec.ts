import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TravelExperienceListComponent } from './travel-experience-list.component';

describe('TravelExperienceListComponent', () => {
  let component: TravelExperienceListComponent;
  let fixture: ComponentFixture<TravelExperienceListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TravelExperienceListComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(TravelExperienceListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
