import { Component, OnInit } from '@angular/core';
import { TravelExperience } from '../travel-experience';
import { TravelExperienceService } from '../travel-experience.service';

@Component({
  selector: 'app-travel-experience-list',
  templateUrl: './travel-experience-list.component.html',
  styleUrl: './travel-experience-list.component.css'
})
export class TravelExperienceListComponent implements OnInit {
  travelExperiences: TravelExperience[];

  constructor(private travelExperienceService: TravelExperienceService) { }

  ngOnInit(): void {
    // Fetch travel experiences from the service
    this.travelExperienceService.getAllTravelExperiences().subscribe(travelExperiences => {
      this.travelExperiences = travelExperiences;
    });
  }
}
