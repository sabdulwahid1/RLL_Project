import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserListComponent } from './user-list/user-list.component';
import { UserDetailsComponent } from './user-details/user-details.component';
import { UserCreateComponent } from './user-create/user-create.component';
import { UserUpdateComponent } from './user-update/user-update.component';
import { TravelExperienceListComponent } from './travel-experience-list/travel-experience-list.component';
import { TravelExperienceDetailsComponent } from './travel-experience-details/travel-experience-details.component';
import { TravelExperienceCreateComponent } from './travel-experience-create/travel-experience-create.component';
import { TravelExperienceUpdateComponent } from './travel-experience-update/travel-experience-update.component';
import { CommentListComponent } from './comment-list/comment-list.component';
import { CommentDetailsComponent } from './comment-details/comment-details.component';
import { CommentCreateComponent } from './comment-create/comment-create.component';
import { CommentUpdateComponent } from './comment-update/comment-update.component';
import { PlaceSuggestionListComponent } from './place-suggestion-list/place-suggestion-list.component';
import { PlaceSuggestionDetailsComponent } from './place-suggestion-details/place-suggestion-details.component';
import { PlaceSuggestionCreateComponent } from './place-suggestion-create/place-suggestion-create.component';
import { PlaceSuggestionUpdateComponent } from './place-suggestion-update/place-suggestion-update.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    UserListComponent,
    UserDetailsComponent,
    UserCreateComponent,
    UserUpdateComponent,
    TravelExperienceListComponent,
    TravelExperienceDetailsComponent,
    TravelExperienceCreateComponent,
    TravelExperienceUpdateComponent,
    CommentListComponent,
    CommentDetailsComponent,
    CommentCreateComponent,
    CommentUpdateComponent,
    PlaceSuggestionListComponent,
    PlaceSuggestionDetailsComponent,
    PlaceSuggestionCreateComponent,
    PlaceSuggestionUpdateComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [
    provideClientHydration()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
