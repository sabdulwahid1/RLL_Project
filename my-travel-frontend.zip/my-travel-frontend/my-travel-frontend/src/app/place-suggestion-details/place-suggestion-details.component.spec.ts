import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PlaceSuggestionDetailsComponent } from './place-suggestion-details.component';

describe('PlaceSuggestionDetailsComponent', () => {
  let component: PlaceSuggestionDetailsComponent;
  let fixture: ComponentFixture<PlaceSuggestionDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PlaceSuggestionDetailsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PlaceSuggestionDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
