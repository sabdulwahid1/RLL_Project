import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PlaceSuggestion } from '../place-suggestion';
import { PlaceSuggestionService } from '../place-suggestion.service';

@Component({
  selector: 'app-place-suggestion-details',
  templateUrl: './place-suggestion-details.component.html',
  styleUrl: './place-suggestion-details.component.css'
})
export class PlaceSuggestionDetailsComponent implements OnInit {
  suggestionId: number;
  placeSuggestion: PlaceSuggestion;

  constructor(private route: ActivatedRoute, private placeSuggestionService: PlaceSuggestionService) { }

  ngOnInit(): void {
    // Extract suggestionId from route params
    this.suggestionId = +this.route.snapshot.paramMap.get('id');
    // Fetch place suggestion details based on suggestionId
    this.placeSuggestionService.getPlaceSuggestionById(this.suggestionId).subscribe(placeSuggestion => {
      this.placeSuggestion = placeSuggestion;
    });
  }
}