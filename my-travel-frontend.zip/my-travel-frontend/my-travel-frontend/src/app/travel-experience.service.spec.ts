import { TestBed } from '@angular/core/testing';

import { TravelExperienceService } from './travel-experience.service';

describe('TravelExperienceService', () => {
  let service: TravelExperienceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TravelExperienceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
