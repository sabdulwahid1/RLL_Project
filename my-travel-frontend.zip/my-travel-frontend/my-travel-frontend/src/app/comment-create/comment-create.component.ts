import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommentService } from '../comment.service';

@Component({
  selector: 'app-comment-create',
  templateUrl: './comment-create.component.html',
  styleUrl: './comment-create.component.css'
})
export class CommentCreateComponent implements OnInit {
  comment: Comment = new Comment();

  constructor(private router: Router, private commentService: CommentService) { }

  ngOnInit(): void {
  }

  createComment(): void {
    // You need to implement logic to associate comments with specific experiences or users
    this.commentService.createComment(this.comment).subscribe(() => {
      this.router.navigate(['/comments']); // Redirect to comment list after creation
    });
  }
}