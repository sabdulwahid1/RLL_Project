import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommentService } from '../comment.service';

@Component({
  selector: 'app-comment-details',
  templateUrl: './comment-details.component.html',
  styleUrl: './comment-details.component.css'
})
export class CommentDetailsComponent implements OnInit {
  commentId: number;
  comment: Comment;

  constructor(private route: ActivatedRoute, private commentService: CommentService) { }

  ngOnInit(): void {
    // Extract commentId from route params
    this.commentId = +this.route.snapshot.paramMap.get('id');
    // Fetch comment details based on commentId
    this.commentService.getCommentById(this.commentId).subscribe(comment => {
      this.comment = comment;
    });
  }
}