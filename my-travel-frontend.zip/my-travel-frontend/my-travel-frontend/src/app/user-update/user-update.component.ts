import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user-update',
  templateUrl: './user-update.component.html',
  styleUrl: './user-update.component.css'
})
export class UserUpdateComponent implements OnInit {
  userId: number;
  user: User;

  constructor(private route: ActivatedRoute, private router: Router, private userService: UserService) { }

  ngOnInit(): void {
    this.userId = +this.route.snapshot.paramMap.get('id'); // Extract userId from route params
    this.userService.getUserById(this.userId).subscribe(user => {
      this.user = user; // Fetch user details based on userId
    });
  }

  updateUser(): void {
    this.userService.updateUser(this.userId, this.user).subscribe(() => {
      this.router.navigate(['/users']); // Redirect to user list after update
    });
  }
}