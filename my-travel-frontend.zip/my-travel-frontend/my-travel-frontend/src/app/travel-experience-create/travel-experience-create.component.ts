import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TravelExperience } from '../travel-experience';
import { TravelExperienceService } from '../travel-experience.service';


@Component({
  selector: 'app-travel-experience-create',
  templateUrl: './travel-experience-create.component.html',
  styleUrl: './travel-experience-create.component.css'
})
export class TravelExperienceCreateComponent implements OnInit {
  travelExperience: TravelExperience = new TravelExperience();

  constructor(private router: Router, private travelExperienceService: TravelExperienceService) { }

  ngOnInit(): void {
  }

  createTravelExperience(): void {
    this.travelExperienceService.createTravelExperience(this.travelExperience).subscribe(() => {
      this.router.navigate(['/travel-experiences']); // Redirect to travel experience list after creation
    });
  }
}