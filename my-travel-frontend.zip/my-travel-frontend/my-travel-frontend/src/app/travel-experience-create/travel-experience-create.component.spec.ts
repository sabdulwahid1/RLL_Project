import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TravelExperienceCreateComponent } from './travel-experience-create.component';

describe('TravelExperienceCreateComponent', () => {
  let component: TravelExperienceCreateComponent;
  let fixture: ComponentFixture<TravelExperienceCreateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TravelExperienceCreateComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(TravelExperienceCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
