import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { TravelExperience } from './travel-experience';


@Injectable({
  providedIn: 'root'
})
export class TravelExperienceService {
  private apiUrl = 'http://localhost:8080/api/travel-experiences'; // Assuming this is the API endpoint for travel experiences

  constructor(private http: HttpClient) { }

  getAllTravelExperiences(): Observable<TravelExperience[]> {
    return this.http.get<TravelExperience[]>(this.apiUrl);
  }

  getTravelExperienceById(experienceId: number): Observable<TravelExperience> {
    const url = `${this.apiUrl}/${experienceId}`;
    return this.http.get<TravelExperience>(url);
  }

  createTravelExperience(travelExperience: TravelExperience): Observable<TravelExperience> {
    return this.http.post<TravelExperience>(this.apiUrl, travelExperience);
  }

  updateTravelExperience(experienceId: number, travelExperience: TravelExperience): Observable<TravelExperience> {
    const url = `${this.apiUrl}/${experienceId}`;
    return this.http.put<TravelExperience>(url, travelExperience);
  }

  deleteTravelExperience(experienceId: number): Observable<void> {
    const url = `${this.apiUrl}/${experienceId}`;
    return this.http.delete<void>(url);
  }
}
