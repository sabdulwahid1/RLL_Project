import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TravelExperienceDetailsComponent } from './travel-experience-details.component';

describe('TravelExperienceDetailsComponent', () => {
  let component: TravelExperienceDetailsComponent;
  let fixture: ComponentFixture<TravelExperienceDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TravelExperienceDetailsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(TravelExperienceDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
