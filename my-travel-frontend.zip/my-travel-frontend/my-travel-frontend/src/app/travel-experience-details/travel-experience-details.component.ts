import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { TravelExperience } from '../travel-experience';
import { TravelExperienceService } from '../travel-experience.service';

@Component({
  selector: 'app-travel-experience-details',
  templateUrl: './travel-experience-details.component.html',
  styleUrl: './travel-experience-details.component.css'
})
export class TravelExperienceDetailsComponent implements OnInit {
  experienceId: number;
  travelExperience: TravelExperience;

  constructor(private route: ActivatedRoute, private travelExperienceService: TravelExperienceService) { }

  ngOnInit(): void {
    // Extract experienceId from route params
    this.experienceId = +this.route.snapshot.paramMap.get('id');
    // Fetch travel experience details based on experienceId
    this.travelExperienceService.getTravelExperienceById(this.experienceId).subscribe(experience => {
      this.travelExperience = experience;
    });
  }
}