import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Comment } from './comment';


@Injectable({
  providedIn: 'root'
})
export class CommentService {
  private apiUrl = 'http://localhost:8080/api/comments'; // Assuming this is the API endpoint for comments

  constructor(private http: HttpClient) { }

  getAllComments(): Observable<Comment[]> {
    return this.http.get<Comment[]>(this.apiUrl);
  }

  getCommentById(commentId: number): Observable<Comment> {
    const url = `${this.apiUrl}/${commentId}`;
    return this.http.get<Comment>(url);
  }

  createComment(comment: Comment): Observable<Comment> {
    return this.http.post<Comment>(this.apiUrl, comment);
  }

  updateComment(commentId: number, comment: Comment): Observable<Comment> {
    const url = `${this.apiUrl}/${commentId}`;
    return this.http.put<Comment>(url, comment);
  }

  deleteComment(commentId: number): Observable<void> {
    const url = `${this.apiUrl}/${commentId}`;
    return this.http.delete<void>(url);
  }
}
