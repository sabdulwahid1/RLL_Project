import { PlaceSuggestion } from './place-suggestion';

describe('PlaceSuggestion', () => {
  it('should create an instance', () => {
    expect(new PlaceSuggestion()).toBeTruthy();
  });
});
