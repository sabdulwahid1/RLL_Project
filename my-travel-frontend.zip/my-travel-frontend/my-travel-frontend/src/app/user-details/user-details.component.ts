import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrl: './user-details.component.css'
})
export class UserDetailsComponent implements OnInit {
  userId: number;
  user: User;

  constructor(private route: ActivatedRoute, private userService: UserService) { }

  ngOnInit(): void {
    // Extract userId from route params
    this.userId = +this.route.snapshot.paramMap.get('id');
    // Fetch user details based on userId
    this.userService.getUserById(this.userId).subscribe(user => {
      this.user = user;
    });
  }
}