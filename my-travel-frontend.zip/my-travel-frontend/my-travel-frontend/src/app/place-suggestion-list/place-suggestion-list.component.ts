import { Component, OnInit } from '@angular/core';
import { PlaceSuggestion } from '../place-suggestion';
import { PlaceSuggestionService } from '../place-suggestion.service';

@Component({
  selector: 'app-place-suggestion-list',
  templateUrl: './place-suggestion-list.component.html',
  styleUrl: './place-suggestion-list.component.css'
})
export class PlaceSuggestionListComponent implements OnInit {
  placeSuggestions: PlaceSuggestion[];

  constructor(private placeSuggestionService: PlaceSuggestionService) { }

  ngOnInit(): void {
    // Fetch place suggestions from the service
    this.placeSuggestionService.getAllPlaceSuggestions().subscribe(placeSuggestions => {
      this.placeSuggestions = placeSuggestions;
    });
  }
}