import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PlaceSuggestionListComponent } from './place-suggestion-list.component';

describe('PlaceSuggestionListComponent', () => {
  let component: PlaceSuggestionListComponent;
  let fixture: ComponentFixture<PlaceSuggestionListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PlaceSuggestionListComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PlaceSuggestionListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
