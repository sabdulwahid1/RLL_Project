import { TestBed } from '@angular/core/testing';

import { PlaceSuggestionService } from './place-suggestion.service';

describe('PlaceSuggestionService', () => {
  let service: PlaceSuggestionService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PlaceSuggestionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
