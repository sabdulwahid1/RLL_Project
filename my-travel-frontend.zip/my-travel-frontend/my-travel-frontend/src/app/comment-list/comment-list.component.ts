import { Component, OnInit } from '@angular/core';
import { CommentService } from '../comment.service';

@Component({
  selector: 'app-comment-list',
  templateUrl: './comment-list.component.html',
  styleUrl: './comment-list.component.css'
})
export class CommentListComponent implements OnInit {
  comments: Comment[];

  constructor(private commentService: CommentService) { }

  ngOnInit(): void {
    // Fetch comments from the service
    this.commentService.getAllComments().subscribe(comments => {
      this.comments = comments;
    });
  }
}
