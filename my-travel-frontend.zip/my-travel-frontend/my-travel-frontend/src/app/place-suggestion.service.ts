import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { PlaceSuggestion } from './place-suggestion';

@Injectable({
  providedIn: 'root'
})
export class PlaceSuggestionService {
  private apiUrl = 'http://localhost:8080/api/place-suggestions'; // Assuming this is the API endpoint for place suggestions

  constructor(private http: HttpClient) { }

  getAllPlaceSuggestions(): Observable<PlaceSuggestion[]> {
    return this.http.get<PlaceSuggestion[]>(this.apiUrl);
  }

  getPlaceSuggestionById(suggestionId: number): Observable<PlaceSuggestion> {
    const url = `${this.apiUrl}/${suggestionId}`;
    return this.http.get<PlaceSuggestion>(url);
  }

  createPlaceSuggestion(placeSuggestion: PlaceSuggestion): Observable<PlaceSuggestion> {
    return this.http.post<PlaceSuggestion>(this.apiUrl, placeSuggestion);
  }

  updatePlaceSuggestion(suggestionId: number, placeSuggestion: PlaceSuggestion): Observable<PlaceSuggestion> {
    const url = `${this.apiUrl}/${suggestionId}`;
    return this.http.put<PlaceSuggestion>(url, placeSuggestion);
  }

  deletePlaceSuggestion(suggestionId: number): Observable<void> {
    const url = `${this.apiUrl}/${suggestionId}`;
    return this.http.delete<void>(url);
  }
}
