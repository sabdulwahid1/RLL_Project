import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PlaceSuggestionUpdateComponent } from './place-suggestion-update.component';

describe('PlaceSuggestionUpdateComponent', () => {
  let component: PlaceSuggestionUpdateComponent;
  let fixture: ComponentFixture<PlaceSuggestionUpdateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PlaceSuggestionUpdateComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PlaceSuggestionUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
