import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { PlaceSuggestion } from '../place-suggestion';
import { PlaceSuggestionService } from '../place-suggestion.service';

@Component({
  selector: 'app-place-suggestion-update',
  templateUrl: './place-suggestion-update.component.html',
  styleUrl: './place-suggestion-update.component.css'
})
export class PlaceSuggestionUpdateComponent implements OnInit {
  suggestionId: number;
  placeSuggestion: PlaceSuggestion;

  constructor(private route: ActivatedRoute, private router: Router, private placeSuggestionService: PlaceSuggestionService) { }

  ngOnInit(): void {
    // Extract suggestionId from route params
    this.suggestionId = +this.route.snapshot.paramMap.get('id');
    // Fetch place suggestion details based on suggestionId
    this.placeSuggestionService.getPlaceSuggestionById(this.suggestionId).subscribe(placeSuggestion => {
      this.placeSuggestion = placeSuggestion;
    });
  }

  updatePlaceSuggestion(): void {
    // You need to implement logic to update the place suggestion
    this.placeSuggestionService.updatePlaceSuggestion(this.suggestionId, this.placeSuggestion).subscribe(() => {
      this.router.navigate(['/place-suggestions']); // Redirect to place suggestion list after update
    });
  }
}