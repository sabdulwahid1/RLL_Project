export class PlaceSuggestion {
    id: number;
    userId: number;
    placeName: string;
    placeCategory: string;
    placeDescription: string;
user: any;
  }
  