import { TravelExperience } from './travel-experience';

describe('TravelExperience', () => {
  it('should create an instance', () => {
    expect(new TravelExperience()).toBeTruthy();
  });
});
