import { Component, OnInit } from '@angular/core';
import { ActivatedRoute,Router} from '@angular/router';
import { CommentService } from '../comment.service';

@Component({
  selector: 'app-comment-update',
  templateUrl: './comment-update.component.html',
  styleUrl: './comment-update.component.css'
})
export class CommentUpdateComponent implements OnInit {
  commentId: number;
  comment: Comment;

  constructor(private route: ActivatedRoute, private router: Router, private commentService: CommentService) { }

  ngOnInit(): void {
    // Extract commentId from route params
    this.commentId = +this.route.snapshot.paramMap.get('id');
    // Fetch comment details based on commentId
    this.commentService.getCommentById(this.commentId).subscribe(comment => {
      this.comment = comment;
    });
  }

  updateComment(): void {
    // You need to implement logic to update the comment
    this.commentService.updateComment(this.commentId, this.comment).subscribe(() => {
      this.router.navigate(['/comments']); // Redirect to comment list after update
    });
  }
}