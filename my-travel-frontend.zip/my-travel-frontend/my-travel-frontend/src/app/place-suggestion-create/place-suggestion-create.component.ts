import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PlaceSuggestion } from '../place-suggestion';
import { PlaceSuggestionService } from '../place-suggestion.service';

@Component({
  selector: 'app-place-suggestion-create',
  templateUrl: './place-suggestion-create.component.html',
  styleUrl: './place-suggestion-create.component.css'
})
export class PlaceSuggestionCreateComponent implements OnInit {
  placeSuggestion: PlaceSuggestion = new PlaceSuggestion();

  constructor(private router: Router, private placeSuggestionService: PlaceSuggestionService) { }

  ngOnInit(): void {
  }

  createPlaceSuggestion(): void {
    // You need to implement logic to create the place suggestion
    this.placeSuggestionService.createPlaceSuggestion(this.placeSuggestion).subscribe(() => {
      this.router.navigate(['/place-suggestions']); // Redirect to place suggestion list after creation
    });
  }
}