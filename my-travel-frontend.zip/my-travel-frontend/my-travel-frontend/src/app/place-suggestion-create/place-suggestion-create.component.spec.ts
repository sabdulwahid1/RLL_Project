import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PlaceSuggestionCreateComponent } from './place-suggestion-create.component';

describe('PlaceSuggestionCreateComponent', () => {
  let component: PlaceSuggestionCreateComponent;
  let fixture: ComponentFixture<PlaceSuggestionCreateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PlaceSuggestionCreateComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(PlaceSuggestionCreateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
