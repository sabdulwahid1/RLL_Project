import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class AdminTest {
 
	WebDriver wd = null;

	@BeforeTest
	public void intiate() 
	{
		//register the webdriver =>browser vendor 
		WebDriverManager.edgedriver().setup();

		//creating an object to the object
		wd = new EdgeDriver();

		//maximize the browser
		wd.manage().window().maximize();

	}

	@Test(priority = 1)
	public void OpenPage() throws InterruptedException {


		JavascriptExecutor js = (JavascriptExecutor) wd;

		//open link
		System.out.println("Open the link ");
		wd.get("http://localhost:4200/");

		//get page title
		String pageTitle = wd.getTitle();
		System.out.println("Page Title: " + pageTitle);
		Thread.sleep(2000);

	}
	
	@Test(priority = 2)
	public void AdminLogin() throws InterruptedException {

		
		wd.findElement(By.linkText("SIGNIN")).click();	
		Thread.sleep(2000);

		//admin login
		wd.findElement(By.id("email")).sendKeys("admin@gmail.com");
		wd.findElement(By.id("password")).sendKeys("123");
		wd.findElement(By.cssSelector("#login > div > div > form > button")).click();	
		Thread.sleep(2000);

	}
	
	

	@Test(priority = 3)
	public void ViewTravelExperience() throws InterruptedException {

		//Go to travel experience page
		wd.findElement(By.linkText("Travel Experience")).click();	
	    Thread.sleep(2000);

	}
	
	@Test(priority = 4)
	public void AddComment() throws InterruptedException {

		//add comment
		wd.findElement(By.cssSelector("body > app-root > app-admindashboard > div > div.body > app-userbooking > div > table > tbody > tr > td:nth-child(9) > button.btn.btn-outline-primary")).click();	
		wd.findElement(By.id("comment")).sendKeys("nice place to visit");	
		wd.findElement(By.cssSelector("body > app-root > app-admindashboard > div > div.body > app-addtour > div > div > div > div.col-md-4 > button")).click();		
		
		Thread.sleep(2000);

	}
	
	@Test(priority = 5)
	public void deleteComment() throws InterruptedException {

		//delete comment
		wd.findElement(By.cssSelector("body > app-root > app-admindashboard > div > div.body > app-addtour > div > table > tbody > tr:nth-child(1) > td:nth-child(4) > button.btn.btn-outline-danger.ms-2")).click();	
		Thread.sleep(2000);

	}
	
	
	@Test(priority = 6)
	public void Signout() throws InterruptedException {

		//signout
		wd.findElement(By.linkText("SignOut")).click();	
		Thread.sleep(2000);

	}
	
	
	
}
