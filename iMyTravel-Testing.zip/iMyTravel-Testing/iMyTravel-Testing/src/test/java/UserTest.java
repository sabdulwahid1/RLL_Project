import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class UserTest {
 
	WebDriver wd = null;

	@BeforeTest
	public void intiate() 
	{
		//register the webdriver =>browser vendor 
		WebDriverManager.edgedriver().setup();

		//creating an object to the object
		wd = new EdgeDriver();

		//maximize the browser
		wd.manage().window().maximize();

	}

	@Test(priority = 1)
	public void OpenPage() throws InterruptedException {


		JavascriptExecutor js = (JavascriptExecutor) wd;

		//open link
		System.out.println("Open the link ");
		wd.get("http://localhost:4200/");

		//get page title
		String pageTitle = wd.getTitle();
		System.out.println("Page Title: " + pageTitle);
		Thread.sleep(2000);

	}
	
	@Test(priority = 2)
	public void UserLogin() throws InterruptedException {

		//Go to user login page
		wd.findElement(By.linkText("SIGNIN")).click();	
		Thread.sleep(2000);

		//Enter user credentials
		wd.findElement(By.id("email")).sendKeys("abdul@gmail.com");
		wd.findElement(By.id("password")).sendKeys("123");
		wd.findElement(By.cssSelector("#login > div > div > form > button")).click();	
		Thread.sleep(2000);

	}
	

	@Test(priority = 3)
	public void AddPlace() throws InterruptedException {

		//go to add place
		wd.findElement(By.cssSelector("body > app-root > app-userdashboard > div > div.body > app-userhome > button")).click();	
		Thread.sleep(2000);

		//add place
		wd.findElement(By.id("placeName")).sendKeys("karnataka");
		wd.findElement(By.id("placeCategory")).sendKeys("city");
		wd.findElement(By.id("placeDescription")).sendKeys("Bangalore is one of the biggest city");
		wd.findElement(By.cssSelector("#login > div > div > form > button")).click();	
		Thread.sleep(2000);

	}
	
	
	@Test(priority = 4)
	public void AddExperience() throws InterruptedException {

		//go to travel exper
		wd.findElement(By.cssSelector("body > app-root > app-userdashboard > div > div.body > app-userhome > div > table > tbody > tr > td:nth-child(4) > button.btn.btn-outline-primary")).click();	
		Thread.sleep(2000);

		//add exper
		wd.findElement(By.id("image")).sendKeys("https://th.bing.com/th?id=ODL.289a019abad8e0f3b89751eee9995557&w=298&h=93&c=10&rs=1&qlt=99&o=6&dpr=1.1&pid=13.1");
		wd.findElement(By.id("costOfTravel")).sendKeys("1000");
		wd.findElement(By.id("heritages")).sendKeys("Bangalore mall of asia");
		wd.findElement(By.id("placesToVisit")).sendKeys("Bangalore fort,mysore sultan summer palace");
		wd.findElement(By.id("accessibility")).sendKeys("ease");
		wd.findElement(By.id("transportation")).sendKeys("Bus,Train");
		wd.findElement(By.id("climate")).sendKeys("chill");
		wd.findElement(By.id("safety")).sendKeys("safe");
		wd.findElement(By.cssSelector("body > app-root > app-userdashboard > div > div.body > app-userprofile > div > div.sub-container.border.p-5 > form > button.btn.btn-primary.float-start")).click();	
		Thread.sleep(2000);

	}
	

	
	@Test(priority = 5)
	public void Signout() throws InterruptedException {

		wd.findElement(By.cssSelector("body > app-root > app-userdashboard > div > div.header > div > div.col-4.text-white.fs-6.mt-2.nav-button > a:nth-child(2)")).click();	
		Thread.sleep(2000);
		

	}
	
}
